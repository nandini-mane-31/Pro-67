import firebase from 'firebase';

// add SDK Firebase
var firebaseConfig = {
  apiKey: "AIzaSyDjSnSpfqwZEy6lXkhrjonqBDpTbTjfgjo",
  authDomain: "voting-app-6e2c9.firebaseapp.com",
  projectId: "voting-app-6e2c9",
  storageBucket: "voting-app-6e2c9.appspot.com",
  messagingSenderId: "439895876894",
  appId: "1:439895876894:web:38e7fe302699bcce7e950f"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase.database();